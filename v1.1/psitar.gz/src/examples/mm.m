# mm.m performs matrix multiplication

multiply(int m, int n, int p, array A^2 <10 10>, array B^2 <10 10>,
	 array C^2 <10 10>)

{
  C=+red omega <2> (A [* omega <0 1>] omega <1 2> B);
}
