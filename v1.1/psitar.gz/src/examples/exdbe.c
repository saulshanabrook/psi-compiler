#include <stdlib.h>
#include "moalib.e"

main()

{
  double *offset0;
  int i0;
  double *shift;
  double _b5[30];
  double _fish[30];
  double _a4[30];

/*******
b5=fish
********/

  shift=_b5+0;
  offset0=_fish+0;
  for (i0=0; i0<30; i0++) {
    *(shift)= *(offset0);
    offset0+=1;
    shift+=1;
  }


/*******
b5=(<5.000000> drop fish) cat (<5.000000> take fish)
********/

  shift=_b5+0;
  offset0=_fish+5;
  for (i0=0; i0<25; i0++) {
    *(shift)= *(offset0);
    offset0+=1;
    shift+=1;
  }
  shift=_b5+25;
  offset0=_fish+0;
  for (i0=0; i0<5; i0++) {
    *(shift)= *(offset0);
    offset0+=1;
    shift+=1;
  }


/*******
a4=(<15.000000> drop ((<15.000000> drop fish) cat (<15.000000> take fish))) cat (<15.000000> take ((<15.000000> drop fish) cat (<15.000000> take fish)))
********/

  shift=_a4+0;
  offset0=_fish+0;
  for (i0=0; i0<15; i0++) {
    *(shift)= *(offset0);
    offset0+=1;
    shift+=1;
  }
  shift=_a4+15;
  offset0=_fish+15;
  for (i0=0; i0<15; i0++) {
    *(shift)= *(offset0);
    offset0+=1;
    shift+=1;
  }


}


