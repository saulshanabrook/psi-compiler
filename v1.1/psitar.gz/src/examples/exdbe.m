main()
{
  array i^0 <>;
  array b5^1 <30>;
  array fish^1 <30>;
  array a4^1 <30>;

  b5 = fish;

  b5 = (<5> drop fish) cat (<5> take fish);

  a4 = (<15> drop ((<15> drop fish) cat (<15> take fish))) cat
       (<15> take ((<15> drop fish) cat (<15> take fish)));

}
