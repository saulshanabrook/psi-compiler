omega_red (array in^3 <5 5 5>, array out1^2 <5 5>, array out2^2 <5 5>, array out3^2 <5 5>, array out4^2 <5 5>, array out5^2 <5 5>)
{
	out5 = (+red omega <2> in) + (*red omega <1> in);
}


