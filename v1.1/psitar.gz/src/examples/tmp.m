# run computes the output of the network for n_i inputs

main()

{
  array B^2 <4 1>;
  array A^2 <1 2>;

  A=<1> pdrop <2 2> ptake B;
}



