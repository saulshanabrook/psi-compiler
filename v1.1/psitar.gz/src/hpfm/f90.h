#define  NOP           0
#define  HPFASSIGN     1
#define  FUNC          2
#define  SPLIT         3
#define  UNRECOGNIZED  4
#define  PREORDER      5
