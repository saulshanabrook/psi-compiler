#define iSHAPE(ident) ident->array.shp
#define vSHAPE(vector) vector->shp
#define eSHAPE(expr) expr->shp
#define iDIM(ident) ident->array.dim
#define eDIM(expr) expr->dim
