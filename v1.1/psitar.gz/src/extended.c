#include "psi.h"

reduce_extended(expr_t *expr, expr_t *result, int top, char *op, int inright)
{
}

code_extended (reduced_t *node)
{
}

mark_extended (statement_t *node)
{
}
