#include <stdio.h>
#include "psi.h"
#include "trans.h"
#include "PGI_PSI.h"

extern ast_stack psi_ast_stack;
statement_t *assn;
extern FILE *cfile, *rfile;
extern int prove, generic;

void PGI_PSI_INIT() {
  psi_ast_stack = NULL;
  mem_init();
  psi_init();
/*  lex_init(); */
  cfile = stdout;
  rfile = stdout;
  prove = TRUE;
  generic = FALSE;


}

void PGI_PSI_ASGN() {
  printf("Constructing PSI ASSIGN node\n");
  assn = get_statement(ASSIGN);
  assn->d.assign->expr = (pop_ast())->psi;
  assn->d.assign->result = (pop_ast())->psi;

}

void PGI_PSI_REDUCE() {
  reduction_init();
  fprintf(stdout, "\n Here is the expression... \n"); 
  rec_print_expr(assn->d.assign->expr); 
  psi_reduce(assn, TRUE);
  fprintf(stdout, "\n Here is the expression... \n"); 
  printf("Top level op is %d\n", assn->d.reduced->d.frag->op);
  rec_print_expr(assn->d.reduced->d.frag); 
  fprintf(stdout, "\n Now for the left \n");
  rec_print_expr(assn->d.reduced->d.frag->left);
  fprintf(stdout, "\n Now for the rightt \n");
  rec_print_expr(assn->d.reduced->d.frag->right);


/*
   FROM parse.c -- do I need to do anything similar?

  result=psi_access(tmp);
  result->psi->loc=loc;
  result->psi->bound=expr->psi->shp;
  assign->d.assign->expr=expr->psi;
  assign->d.assign->result=result->psi;
*/
}

void PSI_PGI_BOOT() {}

void PSI_PGI_FREEMEM() {}
