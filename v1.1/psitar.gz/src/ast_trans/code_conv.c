#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "psi.h"
#include "trans.h"

extern ident_t const1;
ast_stack psi_ast_stack;

void init_psi() {
  psi_ast_stack = NULL;
}

void push_ast(parser_t *cur_expr) {
  ast_stack curnode;

  printf("PUSH... ");

  curnode = (ast_stack)malloc(sizeof(pasnode));
  curnode->next = psi_ast_stack;
  curnode->expr = cur_expr;
  psi_ast_stack = curnode;
}

parser_t *pop_ast() {
  ast_stack curnode;
  parser_t *curexpr;


  printf("POP... ");

  curnode = psi_ast_stack;
  psi_ast_stack = psi_ast_stack->next;
  curexpr = curnode->expr;
  free(curnode);
  return(curexpr);
}

void psi_binop(int opcode) {
  parser_t *l_ast, *r_ast;

  r_ast = pop_ast();
  l_ast = pop_ast();
  push_ast(psi_op(opcode, l_ast, r_ast));
}
  

void psi_unop(int opcode) {
  parser_t *l_ast, *new_expr;

  push_ast(psi_op(opcode, pop_ast(), NULL));
}

void PGI_PSI_PLUS() {
  psi_binop(PLUS);
}

void PGI_PSI_MINUS() {
  psi_binop(MINUS);
}

void PGI_PSI_TIMES() {
  psi_binop(TIMES);
}

void PGI_PSI_DIVIDE() {
  psi_binop(DIVIDE);
}

void PGI_PSI_NOP() {
  psi_unop(NOP);
}

void PGI_PSI_ABS() {
  psi_unop(ABS);
}

void PGI_PSI_NULL() {
  parser_t *p;
  /* I think this is whack -- I think I need to set fields in psi to NULL */
  printf("Processing PGI NULL node\n");
  p = (parser_t *)get_mem(sizeof(parser_t));
  p->ident = NULL;
  p->psi = NULL;
  push_ast(p);
}

void PGI_PSI_CONS(char *name, double psi_val, int is_real) {
  ident_t *i;
  int bogus_i;
  unsigned char bogus_c = 1;

  printf("Processing PGI CONSTANT node with name %s\n", name);
  i = get_ident();
  strcpy(i->string, name);
  i->real = is_real;
  i->value = psi_val;
  i->type = CONSTANT;
  search(name, &bogus_c, &bogus_i);
  i->index = bogus_i;
  printf("%s added to symbol table index %d\n", name, bogus_i); fflush(stdout);
  push_ast((parser_t *)psi_access(i));
}



void PGI_PSI_SCALAR(char *name){
  ident_t *i;
  int bogus_i;
  unsigned char bogus_c = 1;

  printf("Processing PGI SCALAR node with name %s\n", name);
  i = get_ident();
  strcpy(i->string, name);
  i->type = VARIABLE;
  search(name, &bogus_c, &bogus_i);
  printf("Added to symbol table index %d\n", bogus_i); fflush(stdout);
  i->index = bogus_i;
  push_ast((parser_t *)psi_access(i));
}

ident_t *make_id_cnst(double psi_val) {
  ident_t *i;
  i = get_ident();
  i->type = CONSTANT;
  i->value = psi_val;
  i->real = 0;
  i->array.dim = get_ident();
  i->array.dim->value=0.0;
  i->array.shp=NULL;
  return(i);
}
  
ident_t *cnst2parse(int psi_val) {
  ident_t *i;
  int j = 0;
  i = get_ident();
  i->type = ARRAY;
  i->array.dim=&const1;
  i->array.shp=(ident_t **) get_mem(sizeof(ident_t *));
  i->array.shp[0]->type=CONSTANT;
  i->array.shp[0]->real=FALSE;
  i->array.shp[0]->value=psi_val;
  printf("Check %d",j++);fflush(stdout);
  return i;
}

void PGI_PSI_ARRAY(char *name, int dim, int l, int u, int s){
  ident_t *i;
  ident_t *j;
  int bogus_i;
  unsigned char bogus_c = 1;

  printf("Processing PGI ARRAY node with name %s\n", name);
  i = get_ident();
  strcpy(i->string, name);
  i->type = ARRAY;
  search(name, &bogus_c, &bogus_i);
  printf("%s added to symbol table index %d\n", name, bogus_i); fflush(stdout);
  i->index = bogus_i;
/* NOTE - assuming vectors for now! */
  i->array.dim = make_id_cnst(dim);
  printf("Shape is Dim: %d Upper: %d  Lower: %d Stride: %d\n", dim, u,l,s);
  j =  make_id_cnst(u-l+1);
  i->array.shp = (ident_t **) get_mem(sizeof(ident_t *));;
  i->array.shp[0] = j;
  push_ast((parser_t *)psi_access(i));
  printf("pushed array on stack and returning\n"); fflush(stdout);
}
