#include <stdio.h>
#include "../src/psi.h"
#include "trans.h"
#include "PGI_PSI.h"
#include "../src/ops.h"
#include "../src/hpfm/op.h"
#include "../src/sys.h"

extern ast_stack psi_ast_stack;
parser_t *psi_drop(parser_t *, parser_t *);
parser_t *psi_cat(parser_t *, parser_t *);
parser_t *psi_take(parser_t *, parser_t *);
op_t *omega_ize_binary (int dim1, int dim2, psiop_t func);
parser_t *force_order (parser_t *arg1, parser_t *arg2, parser_t *last);
parser_t *psi_omega2(parser_t *arg1, parser_t *arg2, op_t *op);
parser_t *psi_access(ident_t *);
expr_t *get_expr_mem(int);

void PGI_PSI_CONCAT(int dim) {
  parser_t *arg1, *arg2;
  op_t *cop;
  psiop_t func;

  arg1 = pop_ast();
  arg2 = pop_ast();
  func.func = psi_cat;
  cop = omega_ize_binary(dim, dim, func);
  if (dim == 1)
    push_ast(psi_cat(arg1, arg2));
  else
    push_ast(force_order(arg1, arg2, psi_omega2(arg1, arg2, cop)));
}

void PGI_PSI_CSHIFT(int shift_amt, int dim) {
  parser_t *arg1, *arg2;
  expr_t *e2;
  op_t *cop, *dop, *top;
  psiop_t func;
  ident_t *bogi;
  printf("build psi CSHIFT node shift = %d dim = %d\n", shift_amt, dim);

  arg1 = pop_ast();
  arg2 = (parser_t *) get_mem(sizeof(parser_t));

/*  e2 = get_expr_mem(1);
  e2->ident = make_id_cnst(shift_amt);
  e2->op = NOP;
  e2->dim = 0;
  printf("made expr");fflush(stdout);
  bogi = make_vect(e2);
  printf("..converted to vect");fflush(stdout);
  arg2 = vect2parser(bogi);
  printf("..and now into a parser!\n");fflush(stdout);
*/

  bogi = make_id_cnst(shift_amt);
  arg2 = psi_access(bogi);

  if (dim != 1) {
    dim = (int)(arg1->ident->array.dim->value - (dim-1));
    func.func=psi_drop;
    dop = omega_ize_binary(1, dim, func);
    func.func = psi_cat;
    cop = omega_ize_binary(dim, dim, func);
    func.func = psi_take;
    top = omega_ize_binary(1, dim, func);
    push_ast(force_order (arg1, arg2, psi_omega2(psi_omega2(arg2, arg1, dop),
	    psi_omega2(arg2, arg1, top), cop)));
  }
  else {
    push_ast(psi_cat(psi_drop(arg2,arg1), psi_take(arg2, arg1)));
  }

}
