/********************************************************************
 * Filename IO_txl.h
 * Programmer   Bart Fitzgerald
 *
 * Description  This segment provides I/O support for both screen
 *              and files.  This module must be initialized with a
 *              to bInitilizeIO.
 *
 * Version  0.00 Initial code
 *
 ********************************************************************/
/**************
 * Defines
 **************/

#define iMAX_LINE 255

/**************
 * Message numbers
 **************/

#define iNO_ERROR                    0
#define iOPEN_ERROR                  1
#define iREAD_ERROR                  2
#define iUNGET_ERROR                 3
#define iCLOSE_ERROR                 4
#define iNO_FRACTIONAL_DIGITS        5
#define iTOO_MANY_DIGITS             6
#define iFRACTIONAL_TRUNCATION       7
#define iIDENTIFIER_TRUNCATION       8
#define iMEMORY_ALLOCATION_ERROR     9
#define iINVALID_TOKEN_ERROR        10


/*********************
 * External procedure declarations
 *********************/

extern Boolean_t bInitializeIO (char *sSource);
extern char *sGetSourceLine(void);
extern void Warn (int, char *);
extern void Error (int, char *);
extern void FatalError (int, char *);
extern void ExitIO (void);    
extern void TargetOutput (char *);
