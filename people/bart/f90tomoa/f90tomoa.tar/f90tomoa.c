#pragma message ("Copyright (c) 1993 University of MO - Rolla  ::  All rights reserved")

/********************************************************************
 * THIS SOFTWARE IS PROVIDED BY THE DEVELOPER ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE DEVELOPER BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 ********************************************************************/

/********************************************************************
 * Filename     f90tomoa.c
 * Programmer   Bart Fitzgerald
 *
 * Description  Converts a very small subset of FORTRAN 90 to moa
 *              
 * Version  0.01 Initial code
 *
 ********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "standard.h"

#include "lex_f90.h"
#include "io_f90.h"   
#include "parsef90.h"
#include "symtable.h"

#pragma page ()
/**********************************************************
 * Procedure     main
 *
 * Description  Creates a LR(1) action table given a TXL formatted
 *      definition.
 *
 * Precondition  none
 *
 * Return    0 - is sucessiful
 *            != 0 otherwise
 *
 **********************************************************/

int main (int iArgumentCount, char *asArgumentValue[]) {  
    
    if (iArgumentCount < 2) {    
        printf("\nusage: %s source_file output_file", asArgumentValue[0]);
        exit(1);
    } /* if (iArgumentCount < 1) */
        
        
    if (!bInitializeIO(asArgumentValue[1]))
        exit(1);
    if (!bInitializeLexican())
        exit(1);        
    if (!bSymbolTableInitialize())
        exit(1);

    ParseF90ToMOA();
    ExitIO();
    printf("\n");  

    return (0);
}  /* main */
