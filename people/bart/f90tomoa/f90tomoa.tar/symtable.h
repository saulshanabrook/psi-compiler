/********************************************************************
 * Filename Symtable.h
 * Programmer   Bart Fitzgerald
 *
 * Description  This header is required the users of the symbol table.
 *      (Symtable.c).
 *
 * Version  0.03 10/01/93 Initial code
 *
 ********************************************************************/



/********************
 * Indentifier Types
 ********************/

#define STT_SUBROUTINE  0
#define STT_INTEGER     1
#define STT_ARRAY       2

#define iMAX_ARGUMENT   7
#define iMAX_DIMENSION  7


typedef struct structSymbolTableRecord {
    char *sIdentifier;                
    int  iType; 
    union {     
        struct structSymbolTableRecord *apstrArguments[iMAX_ARGUMENT];
        char *asShape[iMAX_DIMENSION];
        }uValue;
    } SymbolTableRecord_t;

/********************
 * External declarations
 ********************/
extern Boolean_t        bSymbolTableInitialize (void);
extern SymbolTableRecord_t *pstrSymbolTablePut (char *);
extern SymbolTableRecord_t *pstrSymbolTableGet (char *);
extern SymbolTableRecord_t *pstrSymbolTableRemoveAny (void);
extern void         SymbolTableRecordFree (SymbolTableRecord_t *);
