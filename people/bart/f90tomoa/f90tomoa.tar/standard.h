/********************************************************************
 * Filename     standard.h
 * Programmer   Bart Fitzgerald
 *
 * Description  This segment provides I/O support for both screen
 *              and files.  This module must be initialized with a
 *              to bInitilizeIO.
 *
 * Externals    none
 * Used
 *
 * Version  0.00 Initial code
 *
 ********************************************************************/

/**************
 * Type Defines
 **************/

typedef enum {
     bFALSE,
     bTRUE
     } Boolean_t;

#define bMALLOC(pointer, type) ((pointer=(type *)malloc(sizeof(type))) == NULL)
#define bCALLOC(pointer, num, type) ((pointer=(type *)calloc(num, sizeof(type))) == NULL)
