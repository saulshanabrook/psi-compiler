/********************************************************************
 * Filename Lex_TXL.h
 * Programmer   Bart Fitzgerald
 *
 * Description  This header is required for the segment LEX_f90.C
 *
 *     >>>>>>   This header has been configured for FORTRAN 90 tokens. <<<<<
 *
 *
 ********************************************************************/

typedef enum {
   tidINVALID_TOKEN,           /* cChar attribute */
   tidOPEN_TOKEN,
   tidCLOSE_TOKEN,
   tidCONTINUE_TOKEN,
   tidEQUAL_TOKEN,
   tidPLUS_TOKEN,
   tidTIMES_TOKEN, 
   tidMINUS_TOKEN,
   tidCOLON_TOKEN,
   tidCOMMA_TOKEN,
   tidDO_TOKEN, 
   tidEND_TOKEN,
   tidREAL_TOKEN,
   tidENDDO_TOKEN,
   tidINTEGER_TOKEN,
   tidALLOCATE_TOKEN,
   tidDIMENSION_TOKEN,
   tidSUBROUTINE_TOKEN,
   tidALLOCATABLE_TOKEN,
   tidIDENTIFIER_TOKEN,
   tidINTEGERNUMBER_TOKEN,
   tidNUMBER_TOKEN,
   tidCOMMENT_EOL_TOKEN,
   tidEOL_TOKEN,
   tidEOF
   } TokenID_t;


/**************
 * Type Defines
 **************/

typedef struct {
    TokenID_t  tidID;
    union {
        char    *sLexeme;
        int     iValue;
        float   fValue;
        } uAttribute;
    } Token_t;



/*********************
 * External procedure declarations
 *********************/

extern Boolean_t bInitializeLexican (void);
extern void InitializeToken(Token_t *);
extern char *sGetTokenText(Token_t *, char *);
extern void GetToken (Token_t *);
extern void GetTokenToEOL (Token_t *);

