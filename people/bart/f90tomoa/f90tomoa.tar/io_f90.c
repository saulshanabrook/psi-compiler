#pragma message ("Copyright (c) 1993 University of MO - Rolla  ::  All rights reserved")

/********************************************************************
 * THIS SOFTWARE IS PROVIDED BY THE DEVELOPER ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE DEVELOPER BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 ********************************************************************/
#pragma subtitle ("IO_F90.c v 0.500")

/********************************************************************
 * Filename IO.c
 * Programmer   Bart Fitzgerald
 *
 * Description  This segment provides I/O support for both screen
 *              and files.  This module must be initialized with a
 *              to bInitilizeIO.
 *
 * Version  0.00 Initial code
 *          0.03.000 Added output
 *
 ********************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "standard.h"

#include "io_f90.h"
                                    
/*******************
 * Messages that corresponds to the message numbers in the io.h file
 *******************/

char *sMessage[] = {
    "",
    "Open error",
    "Read error",
    "Ungetc error",
    "Close error",
    "No fractional digits",
    "Number too long",
    "Fractional part truncated",
    "Identifier truncated",
    "Memory allocation error",
    "Invalid character"
    };


/*******************
 * Segment Variables
 *******************/
char      sSourceLineBuffer[iMAX_LINE];
Boolean_t bSourceClosed;
FILE      *pfSource;
FILE      *pfList;

/*******************
 * Forward Declerations
 *******************/

int iGetCharBuffer (char *pcBuffer, int iCount, FILE *pfText);

#pragma page ()
/**********************************************************
 * Procedure     bInitializeIO
 *
 * Description   Opens files and sets up the screen and
 *       read the first character from the source file
 *       into cNext.
 *
 * Precondition  A source file must exist.
 *
 * Postcondition The input and output files are opened.
 *       The screen is formatted.
 *
 * Param     none
 *
 * Return    bTRUE if a character is loaded from the source file.
 *       bFALSE otherwise
 *
 **********************************************************/

Boolean_t bInitializeIO (char *sSource) {

        /* open files */
    if((pfSource = fopen(sSource, "r" )) == NULL )
        FatalError (iOPEN_ERROR, sSource);
    bSourceClosed = bFALSE;    
    return (bTRUE);

}  /* bInitializeIO */

#pragma page ()
/**********************************************************
 * Procedure     ExitIO
 *
 * Description   Closes files and cleans up the screen.
 *
 * Precondition  A source file must exist.
 *
 * Postcondition The input and output files are closed.
 *       The screen is formatted.
 *
 * Param     none
 *
 * Return    void
 *
 **********************************************************/

void ExitIO (void) {

    if (!bSourceClosed)
        if(fclose(pfSource))
            Error (iCLOSE_ERROR, "Source File");

}  /* bExitIO */

#pragma page ()
/**********************************************************
 * Procedure     sGetSourceLine
 *
 * Description  Finds the next line from the source
 *              buffer.
 *
 * Precondition  pcNext point to the next charater in the
 *               source buffer.
 *
 * Postcondition A charater is returned from the buffer.
 *               pcNext points to the next character in the
 *               source buffer.
 *
 * Param     void
 *
 * Return    The next valid character from the source buffer.
 **********************************************************/

char *sGetSourceLine(void) {
    
    if ((fgets(sSourceLineBuffer, iMAX_LINE, pfSource)) == NULL) {
        if (!bSourceClosed) {
            if (feof(pfSource)) {
                if(fclose(pfSource))
                    Error (iCLOSE_ERROR, "Source File");
                bSourceClosed = bTRUE;
                }
            else
                FatalError(iREAD_ERROR, "Source File");                
            }
        return(NULL);
        }
        
    return (sSourceLineBuffer);                                                       
                
}  /* cGetInputLine */

#pragma page ()
/**********************************************************
 *  Procedure: TargetOutput
 *
 *  Description:  Writes a printf formatted string to the output file
 *
 *  Input:   sOut   The string to be written
 *
 *  Return:  void. 
 **********************************************************/
void TargetOutput (char *sOut) {
    printf("%s", sOut);  
} /* TargetOutput */

#pragma page ()
/**********************************************************
 * Procedure     FatalError
 *
 * Description   Prints the error message to the stderror device
 *       and exits the program.
 *
 * Precondition  none
 *
 * Postcondition Prints the error message and exits the program.
 *
 * Param     iMessage - The number of the message to be printed.
 *
 * Return    void
 **********************************************************/

void FatalError (int iMessage, char *sInformation) {
    char sBuffer[80];

    sprintf(sBuffer, "\nFatal Error: %s: %s", sMessage[iMessage], sInformation);
    perror(sBuffer);

    exit(iMessage);

}  /* FatalError */

#pragma page ()
/**********************************************************
 * Procedure     Error
 *
 * Description   Prints the Error message.
 *
 * Precondition  none
 *
 * Postcondition Prints the error message and exits the program.
 *
 * Param     iMessage - The number of the message to be printed.
 *
 * Return    void
 **********************************************************/

void Error (int iMessage, char *sInformation) {

    printf("\nError: %s: %s", sMessage[iMessage], sInformation);

}  /* Error */

#pragma page ()
/**********************************************************
 * Procedure     Warn
 *
 * Description   Prints the warning message.
 *
 * Precondition  none
 *
 * Postcondition Prints the error message and exits the program.
 *
 * Param     iMessage - The number of the message to be printed.
 *
 * Return    void
 **********************************************************/

void Warn (int iMessage, char *sInformation) {

    printf("\nWarning: %s: %s", sMessage[iMessage], sInformation);

}  /* Warn */

