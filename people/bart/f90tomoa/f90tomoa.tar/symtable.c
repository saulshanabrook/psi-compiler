#pragma message ("Copyright (c) 1993 University of MO - Rolla  ::  All rights reserved")

/********************************************************************
 * THIS SOFTWARE IS PROVIDED BY THE DEVELOPER ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE DEVELOPER BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 ********************************************************************/
#pragma subtitle ("Symtable.c v 0.400")

/********************************************************************
 * Filename     Symtable.c
 * Programmer   Bart Fitzgerald
 *
 * Description  This is a portion of a compiler.
 *              This is a symbol table.  It stores and retrives identifiers.
 *
 * Version  0.03.001 10/01/93 Initial code
 *          0.04.001 11/06/93 Bart
 *            Added pstrSymbolTableRemoveAny and
 *              SymbolTableRecordFree.
 *          0.400 11/19/93 Bart
 *              Version Stamp (no changes)
 *
 ********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "standard.h"

#include "symtable.h"
#include "io_f90.h"

/****************
 * Local Defines
 ****************/

#define iHASH_TABLE_SIZE   17     /* primes work best */
#define iHASH_SHIFT_LIMIT  15
#define iTABLE_TYPES        1

/****************
 * Local Types
 ****************/

typedef struct strBinaryTreeNode {
    SymbolTableRecord_t      *pstrRecord;
    struct strBinaryTreeNode *pbtnLeft;
    struct strBinaryTreeNode *pbtnRight;
    } BinaryTreeNode_t;


    /* track which roots were hashed to */
typedef struct strBinaryTreeUsed {
    BinaryTreeNode_t         **ppbtnUsed;
    struct strBinaryTreeUsed *pbtuNext;
    } BinaryTreeUsed_t;

typedef struct strScope {
    int          iLevel;
    BinaryTreeNode_t *apbtnTree[iHASH_TABLE_SIZE];
    BinaryTreeUsed_t *pbtuUsed;
    struct strScope  *pscNext;
    } Scope_t;   /* sc */

/****************
 * Local Variables
 ****************/

Scope_t *pscTable;  /* pointer to first scope */

char *sCurrentIdentifier;

/**************
 * Forward Declarations
 **************/

SymbolTableRecord_t  *pstrInsert     (Scope_t *pscList);
SymbolTableRecord_t  *pstrRetrive    (Scope_t *pscList);
BinaryTreeNode_t    **ppbtnBinaryTreeGet (BinaryTreeNode_t **);
int iHash (void);

#pragma page ()
/**********************************************************
 * Procedure     bSymbolTableInitialize
 *
 * Description   Sets the tables to NULL
 *
 * Precondition  none
 *
 * Postcondition The symbol table arrays are set to NULL
 *
 * Param     none
 *
 * Return    bTRUE
 *
 **********************************************************/

Boolean_t bSymbolTableInitialize (void) {
    int iRoot;

    if (bMALLOC (pscTable, Scope_t))
    FatalError(iMEMORY_ALLOCATION_ERROR, "Sym TXL");
    pscTable->iLevel   = 0;
    pscTable->pscNext  = NULL;
    pscTable->pbtuUsed = NULL;
    for (iRoot = 0; iRoot < iHASH_TABLE_SIZE; iRoot++)
    pscTable->apbtnTree[iRoot] = NULL;

    return (bTRUE);

}  /* bSymbolTableInitialize */

#pragma page ()
/**********************************************************
 * Procedure     pstrSymbolTablePut
 *
 * Description   Inserts an identifier into the table
 *
 * Precondition  The symbol table table has been initialized
 *
 * Postcondition The identifier is added to the table and the
 *       new symbol table node is returned.  If the
 *       identifier was already there, no change is
 *       made to the symbol table and NULL is returned.
 *
 * Param     sttType     - the type of the identifier.
 *       sIdentifier - the identifier string.
 *
 * Return    A pointer to the new symbol table node or
 *       NULL is a node already exists
 *
 **********************************************************/

SymbolTableRecord_t *pstrSymbolTablePut (char *sIdentifier) {

    sCurrentIdentifier = sIdentifier;

    return (pstrInsert(pscTable));

}  /* pstrSymbolTablePut */

#pragma page ()
/**********************************************************
 * Procedure     pstrSymbolTableGet
 *
 * Description   Retrives an identifier from the table
 *
 * Precondition  The symbol table table has been initialized
 *
 * Postcondition A pointer to a symbol table record is returned.
 *
 * Param     sttType     - the type of the identifier.
 *       sIdentifier - the identifier string.
 *
 * Return    A pointer to the symbol table record or
 *       NULL the record does not exist.
 *
 **********************************************************/

SymbolTableRecord_t *pstrSymbolTableGet (char *sIdentifier) {

    sCurrentIdentifier = sIdentifier;

    return (pstrRetrive(pscTable));

}  /* pstrSymbolTableGet */

#pragma page ()
/**********************************************************
 * Procedure     pstrSymbolTableRemoveAny
 *
 * Description   Retrives and removes any identifier from the table
 *
 * Precondition  The symbol table table has been initialized
 *
 * Postcondition A pointer to a symbol table record is returned and
 *       the binary tree node is distoryed.
 *
 * Param
 *
 *
 * Return    A pointer to the symbol table record or
 *       NULL is none exsist
 *
 **********************************************************/

SymbolTableRecord_t *pstrSymbolTableRemoveAny (void) {
    BinaryTreeUsed_t    *pbtuHere;
    BinaryTreeNode_t   **ppbtnFrom;
    BinaryTreeNode_t   **ppbtnHere;
    SymbolTableRecord_t *pstrThisOne;

    if ((pbtuHere = pscTable->pbtuUsed) == NULL)
    return(NULL);

    if ((*(ppbtnHere = &((*(ppbtnFrom = pbtuHere->ppbtnUsed))->pbtnLeft))) == NULL)
    if ((*(ppbtnHere = &((*ppbtnFrom)->pbtnRight))) == NULL) {
        pscTable->pbtuUsed = pbtuHere->pbtuNext;
        free (pbtuHere);
        } /* if ((((pbtnHere... */

    while (*ppbtnHere != NULL) {
    if ((*(ppbtnHere = &((*(ppbtnFrom = ppbtnHere))->pbtnLeft))) == NULL)
        ppbtnHere = &((*ppbtnFrom)->pbtnRight);
    } /* while (pbtnHere != NULL) */

    pstrThisOne = (*ppbtnFrom)->pstrRecord;
    free(*ppbtnFrom);
    *ppbtnFrom = NULL;

    return (pstrThisOne);

}  /* pstrSymbolTableRemoveAny */

#pragma page ()
/**********************************************************
 * Procedure     pstrInsert
 *
 * Description   Inserts sCurrentIdentifier into the binary tree
 *       roted at pbtnRoot
 *
 * Precondition  none
 *
 * Postcondition The symbol table arrays are set to NULL
 *
 * Param     none
 *
 * Return    The new symbol table record or
 *       NULL is a record already exists
 *
 **********************************************************/

SymbolTableRecord_t *pstrInsert (Scope_t *pscCurrent) {
    BinaryTreeNode_t **ppbtnRoot = &(pscCurrent->apbtnTree[iHash()]);
    BinaryTreeNode_t **ppbtnNew;
    BinaryTreeNode_t *pbtnNew;
    SymbolTableRecord_t      *pstrNew;

    if ((*(ppbtnNew = ppbtnBinaryTreeGet(ppbtnRoot))) != NULL)
        return (NULL);

    if (ppbtnNew == ppbtnRoot) {
        BinaryTreeUsed_t *pbtuNew;
        if (bMALLOC(pbtuNew, BinaryTreeUsed_t))
            FatalError(iMEMORY_ALLOCATION_ERROR, "Sym TXL");
        pbtuNew->ppbtnUsed   = ppbtnRoot;
        pbtuNew->pbtuNext   = pscCurrent->pbtuUsed;
        pscCurrent->pbtuUsed = pbtuNew;
        } /* if (ppbtnNew == ppbtnRoot) */


        /* make a binary tree node */
    if (bMALLOC(*ppbtnNew, BinaryTreeNode_t))
        FatalError(iMEMORY_ALLOCATION_ERROR, "Sym TXL");
    (pbtnNew = *ppbtnNew)->pbtnLeft = NULL;
    pbtnNew->pbtnRight          = NULL;

        /* make a symbol table record */
    if (bMALLOC(pbtnNew->pstrRecord, SymbolTableRecord_t))
        FatalError(iMEMORY_ALLOCATION_ERROR, "Sym TXL");

    pstrNew = pbtnNew->pstrRecord;

        /* make room for the identifier string */
    if (bCALLOC(pstrNew->sIdentifier, strlen(sCurrentIdentifier)+1, char))
        FatalError(iMEMORY_ALLOCATION_ERROR, "Sym TXL");
    strcpy(pstrNew->sIdentifier, sCurrentIdentifier);

    return (pstrNew);

}  /* pstrInsert */

#pragma page ()
/**********************************************************
 * Procedure     pstrRetrive
 *
 * Description   Inserts sCurrentIdentifier into the binary tree
 *       roted at pbtnRoot
 *
 * Precondition  none
 *
 * Postcondition The symbol table arrays are set to NULL
 *
 * Param     none
 *
 * Return    The new symbol table record or
 *       NULL is a record already exists
 *
 **********************************************************/

SymbolTableRecord_t *pstrRetrive (Scope_t *pscList) {
    int iTree = iHash();
    BinaryTreeNode_t    **ppbtnRetrive;
    SymbolTableRecord_t  *pstrRetrive;

    while (pscList != NULL) {

    if ((*(ppbtnRetrive = ppbtnBinaryTreeGet(&(pscList->apbtnTree[iTree])))) != NULL) {
        pstrRetrive = (*ppbtnRetrive)->pstrRecord;
        return (pstrRetrive);
        }
    pscList = pscList->pscNext;
    } /* while (pscList != NULL) */

    return (NULL);

}  /* pstrRetrive */

#pragma page ()
/**********************************************************
 * Procedure     ppbtnBinaryTreeGet
 *
 * Description   Gets a binary tree node if it exsists
 *
 * Precondition  ppbtnRoot is the address of a root to a binary tree
 *       that is to be searched for sCurrentIdentifier.
 *
 * Postcondition The tree remains unchanged.  A pointer to the
 *       tree's pointers to the node is returned.  If the
 *       value of the pointer's pointer is NULL, then this is
 *       where sCurrentIdentifier should be.
 *
 * Param     ppbtnRoot - a pointer to the root pointer to the tree
 *
 * Return    A pointer to the tree's pointer to the node.  If the
 *       tree's pointer is NULL then the key was not found.
 *
 **********************************************************/

BinaryTreeNode_t **ppbtnBinaryTreeGet(BinaryTreeNode_t **ppbtnRoot) {

    int iResult;
    BinaryTreeNode_t *pbtnCurrent;

  TailRecursion:

    if (*ppbtnRoot == NULL)
    return (ppbtnRoot);

    pbtnCurrent = *ppbtnRoot;
    if ((iResult = strcmp (sCurrentIdentifier,
               pbtnCurrent->pstrRecord->sIdentifier)) < 0) {
    ppbtnRoot = &(pbtnCurrent->pbtnLeft);
    goto TailRecursion;
    }
    else if (iResult > 0) {
    ppbtnRoot = &(pbtnCurrent->pbtnRight);
    goto TailRecursion;
    }

    return (ppbtnRoot);

}  /* ppbtnBinaryTreeGet */

#pragma page ()
/**********************************************************
 * Procedure     iHash
 *
 * Description   Hashes the last characters of the
 *       sCurrentIdentifier
 *
 * Precondition  sCurrentIdentifier contains a string
 *
 * Postcondition A number is returned
 *
 * Param     none
 *
 * Return    A hash number
 *
 **********************************************************/

int iHash (void) {
    int iLoop;
    int iSize        = strlen(sCurrentIdentifier);
    char *pcCurrent  = sCurrentIdentifier + (iSize-1);
    int  iAccumulate = 0;
    int  iShifter;

    if (iSize > iHASH_SHIFT_LIMIT)
    iSize = iHASH_SHIFT_LIMIT;

    for (iLoop = 0; iLoop < iSize; iLoop++) {
    iShifter    = *pcCurrent;
    *pcCurrent--;
    iShifter      <<= iLoop;
    iAccumulate    ^= iShifter;
    } /* for (iLoop = 0... */

    return (abs(iAccumulate % iHASH_TABLE_SIZE));

}  /* iHash */

#pragma page ()
/**********************************************************
 * Procedure     SymbolTableRecordFree
 *
 * Description   frees the space used by a symbol table record.
 *
 * Precondition  pstrDistroy is a pointer to a valid symbol
 *       table record or NULL.
 *
 * Postcondition Deallocates the space used by a record and
 *       sets it to NULL.
 *
 * Param     pstrDistroy - a record to destroyed
 *
 * Return    void
 *
 **********************************************************/

void SymbolTableRecordFree (SymbolTableRecord_t *pstrDistroy) {

    if (pstrDistroy != NULL) {
    free (pstrDistroy->sIdentifier);
    free (pstrDistroy);
    pstrDistroy = NULL;
    } /* if (pstrDistroy != NULL) */

}  /* pstrSymbolTableGet */
