#pragma message ("Copyright (c) 1993 University of MO - Rolla  ::  All rights reserved")

/********************************************************************
 * THIS SOFTWARE IS PROVIDED BY THE DEVELOPER ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE DEVELOPER BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 ********************************************************************/

/********************************************************************
 * Filename     parsef90.c
 * Programmer   Bart Fitzgerald
 *
 * Description  Parser for FORTRAN 90 to moa (very limited)
 *
 * Externals    GetToken                    Lexican.c
 * Used         GetTokenToEOL               Lexican.c
 *              pstrSymbolTableGet          SymTable.c
 *              pstrSymbolTablePut          SymTable.c
 *              pstrSymbolTableRemoveAny    SymTable.c
 *              SymbolTableRecordFree       SymTable.c
 *              FatalError                  IO.c
 *              bCALLOC                     Standard.h
 *              bMALLOC                     Standard.h
 *              
 * Version  0.01 Initial code
 *
 ********************************************************************/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "standard.h"

/*  #include "parse.h" */
#include "lex_f90.h"
#include "io_f90.h"
#include "symtable.h"

/****************
 * Local Define
 ****************/

#define MARGIN_SIZE 4    
#define NEW_LINE   60

/****************
 * Local Variables
 ****************/

Token_t tCurrent;  

const char *sOne      = "1";
const char *sMinusOne = "-1";

int  iLineCount;
int  iMargin;
char asStatement[30][iMAX_LINE];

Boolean_t bArrayAssignment;

/****************
 * Function Prototypes
 ****************/

char *sExpression(char *sLine);                  
void Statement(void);

#pragma page ()
/**********************************************************
 * Procedure     Match
 *
 * Description   Compares the current token with the
 *       expected token.  If found the next token
 *       is read as ptCurrent.  Otherwise,
 *       syntax error has occured.
 *
 * Precondition  ptCurrent contains a token.
 *
 * Postcondition ptCurrent contains the next token from Lexican
 *
 * Param     tidExpected - the expected token ID
 *
 * Return    void
 *
 **********************************************************/

void Match (TokenID_t tidExpected) {

  if (tCurrent.tidID == tidExpected)
      GetToken (&tCurrent);
  else {
      char sBuffer1[iMAX_LINE];
      char sBuffer2[iMAX_LINE];
      sprintf (sBuffer1, "Syntax Error : '%s' ",
                    sGetTokenText(&tCurrent, sBuffer2));
      perror (sBuffer1);
      exit (1);
      }

} /* Match */

#pragma page ()
/**********************************************************
 * Procedure     iDummyArgumentList
 *
 * Description   Creates a Symbol Table Record of each argument
 *               and builds a linked list for the subroutine
 *
 * Param            void
 *
 * Return           void
 **********************************************************/

int iDummyArgumentList(SymbolTableRecord_t *p_strSubroutine) {
    char sBuffer[iMAX_LINE];
    int  iArgumentCount = -1;
    SymbolTableRecord_t *pstrNew;
                                                  
    Match(tidOPEN_TOKEN);
                            
    while (tCurrent.tidID != tidCLOSE_TOKEN) {
        pstrNew = pstrSymbolTablePut (sGetTokenText(&tCurrent, sBuffer));
        Match(tidIDENTIFIER_TOKEN);
        p_strSubroutine->uValue.apstrArguments[++iArgumentCount] = pstrNew;
        if (tCurrent.tidID == tidCOMMA_TOKEN)
            GetToken(&tCurrent);
        }    
    GetToken(&tCurrent); /* CLOSE_TOKEN */
    Match(tidEOL_TOKEN);   
    
    return (++iArgumentCount);
} /* iDummyArgumentList */
    
#pragma page ()
/**********************************************************
 * Procedure     ArgumentList
 *
 * Description   Creates a Symbol Table Record of each argument
 *               and builds a linked list for the subroutine
 *
 **********************************************************/

void ArgumentList(SymbolTableRecord_t *p_strSubroutine) {
    int                 iArgumentCount = iDummyArgumentList(p_strSubroutine);
    int                 iArgumentIndex;
    int                 iShapeIndex;
    int                 iDimension;
    char                *sArgument;
    char                *sShape;
    char                asShapes[iMAX_DIMENSION][iMAX_LINE];
    char                sBuffer[iMAX_LINE];
    Boolean_t           bArray;                                 
    Boolean_t           bFirstArgument;                                 
    Boolean_t           bFirstShape;                                 
    SymbolTableRecord_t *p_strArgument;
                                   
    bFirstArgument = bTRUE;
    for (iArgumentIndex = 0; iArgumentIndex < iArgumentCount; iArgumentIndex++) {   
        p_strArgument = p_strSubroutine->uValue.apstrArguments[iArgumentIndex];
        if (tCurrent.tidID == tidREAL_TOKEN) {
            bArray = bTRUE;
            iDimension = 0;
            asShapes[0][0] = '\0';
            GetToken(&tCurrent);
            }            
        else {
            bArray = bFALSE;
            Match(tidINTEGER_TOKEN);
            }
                                    
        if (tCurrent.tidID == tidCOMMA_TOKEN) {
            bArray = bTRUE;
            GetToken(&tCurrent);                         
            Match(tidDIMENSION_TOKEN);
            Match(tidOPEN_TOKEN);
            iDimension = -1;
            while (tCurrent.tidID != tidCLOSE_TOKEN) {
                asShapes[++iDimension][0] = '\0';
                while (  (tCurrent.tidID != tidCOMMA_TOKEN) 
                      && (tCurrent.tidID != tidCLOSE_TOKEN)) {
                    sprintf(asShapes[iDimension],
                            "%s%s", 
                            asShapes[iDimension], 
                            sGetTokenText(&tCurrent, sBuffer));
                    GetToken(&tCurrent);
                    } /* while ((tCurrent.tidID != tidCOMMA_TOKEN)... */
                if (tCurrent.tidID == tidCOMMA_TOKEN) 
                    GetToken(&tCurrent);
                } /* while (tCurrent.tidID != tidCLOSE_TOKEN) */
            ++iDimension;    
            GetToken(&tCurrent); /* CLOSE_TOKEN */
            } /* if (tCurrent.tidID == tidCOMMA_TOKEN) */
        Match(tidCOLON_TOKEN);        
        Match(tidCOLON_TOKEN);
        while (tCurrent.tidID != tidEOL_TOKEN) {
            if (!bFirstArgument)
                printf (", ");        
            if (strcmp((sArgument = p_strArgument->sIdentifier), tCurrent.uAttribute.sLexeme)) {
                perror ("Argumemt list and deinitions must be in the same order.");
                exit(1);
                }
            if (bArray) {                 
                p_strArgument->iType = STT_ARRAY;
                printf("array %s^%i <", sArgument, iDimension);
                bFirstShape = bTRUE;
                for (iShapeIndex=0; iShapeIndex < iDimension; iShapeIndex++) {
                    if (bFirstShape) {
                        bFirstShape = bFALSE;
                        printf("%s", (sShape = asShapes[iShapeIndex]));
                        }
                    else
                        printf(", %s", (sShape = asShapes[iShapeIndex]));
                    p_strArgument->uValue.asShape[iShapeIndex] = 
                            (char *)calloc(strlen(sShape)+1, sizeof(char));
                    strcpy(p_strArgument->uValue.asShape[iShapeIndex], sShape);
                    } /* for (iShapeIndex=0;... */
                p_strArgument->uValue.asShape[iShapeIndex] = NULL;
                printf(">", asShapes[iShapeIndex]);
                } /* if (bArray) */
            else {
                printf("int %s", sArgument);
                p_strArgument->iType = STT_INTEGER;
                }             
             Match(tidIDENTIFIER_TOKEN);
             if (tCurrent.tidID == tidCOMMA_TOKEN) {
                iArgumentIndex++;       
                p_strArgument = p_strSubroutine->uValue.apstrArguments[iArgumentIndex];
                GetToken(&tCurrent); /* tidCOMMA_TOKEN */
                }
            bFirstArgument = bFALSE;
            } /* while (tCurrent.tidID != tidEOL_TOKEN) */
        GetToken(&tCurrent); /* tidEOL_TOKEN */
        } /* for (; iArgumentCount; iArgumentCount++) */
} /* ArgumentList */    
        
#pragma page ()
/**********************************************************
 * Procedure     SpecificationPart
 *
 * Description   Creates a Symbol Table Record of each Specification
 *
 **********************************************************/

void SpecificationPart(void) {
    int                 iShapeIndex;
    int                 iDimension;
    char                sVariable[iMAX_LINE];
    char                asShapes[iMAX_DIMENSION][iMAX_LINE];
    char                sBuffer[iMAX_LINE];
    Boolean_t           bArray;                                 
    SymbolTableRecord_t *p_strArgument;
        
    while ((tCurrent.tidID == tidINTEGER_TOKEN) || (tCurrent.tidID == tidREAL_TOKEN)) {
        if (tCurrent.tidID == tidREAL_TOKEN) {
            bArray = bTRUE;
            iDimension = 0;
            asShapes[0][0] = '\0';
            GetToken(&tCurrent);
            }            
        else {
            bArray = bFALSE;
            Match(tidINTEGER_TOKEN);
            }
                                    
        if (tCurrent.tidID == tidCOMMA_TOKEN) {
            bArray = bTRUE;
            GetToken(&tCurrent); /* tidCOMMA_TOKEN */
            if (tCurrent.tidID == tidALLOCATABLE_TOKEN) {
                GetToken(&tCurrent); /* tidALLOCATABLE_TOKEN */
                Match(tidCOMMA_TOKEN);
                }
            Match(tidDIMENSION_TOKEN);
            Match(tidOPEN_TOKEN);
            iDimension = -1;
            while (tCurrent.tidID != tidCLOSE_TOKEN) {
                asShapes[++iDimension][0] = '\0';
                while (  (tCurrent.tidID != tidCOMMA_TOKEN) 
                      && (tCurrent.tidID != tidCLOSE_TOKEN)) {
                    sprintf(asShapes[iDimension],
                            "%s%s", 
                            asShapes[iDimension], 
                            sGetTokenText(&tCurrent, sBuffer));
                    GetToken(&tCurrent);
                    } /* while ((tCurrent.tidID != tidCOMMA_TOKEN)... */
                if (tCurrent.tidID == tidCOMMA_TOKEN) 
                    GetToken(&tCurrent);
                } /* while (tCurrent.tidID != tidCLOSE_TOKEN) */
            ++iDimension;    
            GetToken(&tCurrent); /* CLOSE_TOKEN */
            } /* if (tCurrent.tidID == tidCOMMA_TOKEN) */
        Match(tidCOLON_TOKEN);        
        Match(tidCOLON_TOKEN);
        while (tCurrent.tidID != tidEOL_TOKEN) {
            strcpy(sVariable, tCurrent.uAttribute.sLexeme);
            Match(tidIDENTIFIER_TOKEN);
            if ((p_strArgument = pstrSymbolTableGet(sVariable)) == NULL) 
                p_strArgument = pstrSymbolTablePut(sVariable);
            if (bArray) {                 
                p_strArgument->iType = STT_ARRAY;
                for (iShapeIndex=0; iShapeIndex < iDimension; iShapeIndex++) {
                    p_strArgument->uValue.asShape[iShapeIndex] = 
                            (char *)calloc(strlen(asShapes[iShapeIndex])+1, sizeof(char));
                    strcpy(p_strArgument->uValue.asShape[iShapeIndex], asShapes[iShapeIndex]);
                    } /* for (iShapeIndex=0;... */
                p_strArgument->uValue.asShape[iShapeIndex] = NULL;
                } /* if (bArray) */
            else
                p_strArgument->iType = STT_INTEGER;
                
             if (tCurrent.tidID == tidCOMMA_TOKEN) 
                GetToken(&tCurrent); /* tidCOMMA_TOKEN */
            } /* while (tCurrent.tidID != tidEOL_TOKEN) */
        GetToken(&tCurrent); /* tidEOL_TOKEN */
        } /* while ((tCurrent.tidID == tidINTEGER)... */
} /* SpecificationPart */    
        
/**********************************************************
 * Procedure     sDoStatement
 *
 * Description   Builds a Linked list of MOA instructions
 *
 **********************************************************/

void DoStatement(char *sLine) {  
    char sBuffer[iMAX_LINE];
    char sIndex[iMAX_LINE];
    SymbolTableRecord_t *p_strIndex;

    Match(tidDO_TOKEN);
    sprintf(sLine, "%*cforall (<", iMargin, ' ');
    sGetTokenText(&tCurrent, sIndex);
    Match(tidIDENTIFIER_TOKEN); /* index var */
    Match(tidEQUAL_TOKEN);
    while (tCurrent.tidID != tidCOMMA_TOKEN) {
        sprintf(sLine,"%s%s", sLine, sGetTokenText(&tCurrent, sBuffer));
        GetToken(&tCurrent);
        }
    GetToken(&tCurrent);    
    sprintf(sLine,"%s> <= %s < <", sLine, sIndex);
    while (tCurrent.tidID != tidEOL_TOKEN) {
        sprintf(sLine,"%s%s", sLine, sGetTokenText(&tCurrent, sBuffer));
        GetToken(&tCurrent);
        }
    GetToken(&tCurrent); /* tidEOL_TOKEN */        
    sprintf(sLine,"%s%s>) {\n", sLine, "+1");
    
    if ((p_strIndex = pstrSymbolTableGet(sIndex))->iType != STT_ARRAY) { 
        p_strIndex->iType = STT_ARRAY;
        p_strIndex->uValue.asShape[0] = (char *)calloc(2, sizeof(char));
        strcpy(p_strIndex->uValue.asShape[0], sOne);
        p_strIndex->uValue.asShape[1] = NULL;
        }
    
} /* DoStatement */
            
/**********************************************************
 * Procedure     AllocateStatement
 *
 * Description   
 *
 **********************************************************/
void AllocateStatement(char *sLine) {
    char *sArray;                                  
    char sBuffer[iMAX_LINE];
    Boolean_t bFirst = bTRUE;
        
    Match(tidALLOCATE_TOKEN);
    Match(tidOPEN_TOKEN);
    strcpy(sArray, sGetTokenText(&tCurrent, sBuffer));
    Match(tidIDENTIFIER_TOKEN);
    Match(tidOPEN_TOKEN);
    sprintf(sLine, "%*callocate %s <", iMargin, ' ', sArray);
    while (tCurrent.tidID != tidCLOSE_TOKEN) {
        if (bFirst)
            bFirst = bFALSE;
        else    
            sprintf(sLine, "%s ", sLine);
        while ((tCurrent.tidID != tidCOMMA_TOKEN) && (tCurrent.tidID != tidCLOSE_TOKEN)) {
            sprintf(sLine, "%s%s", sLine, sGetTokenText(&tCurrent, sBuffer));     
            GetToken(&tCurrent);
            } /* while ((tCurrent.tidID != tidCOMMA_TOKEN) &&... */
        if (tCurrent.tidID == tidCOMMA_TOKEN)
            GetToken(&tCurrent);
        } /* while (tCurrent.tidID != tidCLOSE_TOKEN) */
    sprintf(sLine, "%s>;\n", sLine);
    Match(tidCLOSE_TOKEN);
    Match(tidCLOSE_TOKEN);
    Match(tidEOL_TOKEN);
    
} /* AllocateStatement */

/**********************************************************
 * Procedure     VarAccess
 *
 * Description   
 *
 **********************************************************/
void VarAccess(char *sLine) {                      
    int  iAdjust;
    int  iShapeIndex;
    int  iShapeCount = 0;
    char sBuffer[iMAX_LINE];
    char sVar[iMAX_LINE];
    char sLower[iMAX_DIMENSION][iMAX_LINE];
    char sUpper[iMAX_DIMENSION][iMAX_LINE];
    Boolean_t bTake = bFALSE;
    Boolean_t bDrop = bFALSE;   
    Boolean_t bFirst;
    SymbolTableRecord_t *p_strVar;
    
    if ((p_strVar = pstrSymbolTableGet(sGetTokenText(&tCurrent, sVar))) == NULL) {
        perror("FATAL ERROR: Uninitialized variable");
        exit(1);
        } 
    if (p_strVar->iType == STT_ARRAY)
        bArrayAssignment = bTRUE;
    Match(tidIDENTIFIER_TOKEN);
    if (tCurrent.tidID != tidOPEN_TOKEN) {          
        sprintf (sLine,"%s%s", sLine, sVar);
        return;
        } /* if (tCurrent.tidID != tidOPEN_TOKEN) */
     GetToken(&tCurrent);
     while (tCurrent.tidID != tidCLOSE_TOKEN) {         
        sLower[iShapeCount][0] = '\0';
        while (tCurrent.tidID != tidCOLON_TOKEN) {
            bDrop = bTRUE;
            sprintf(sLower[iShapeCount], "%s%s", sLower[iShapeCount], sGetTokenText(&tCurrent, sBuffer));
            GetToken(&tCurrent);
            } 
        GetToken(&tCurrent);    
        sUpper[iShapeCount][0] = '\0';
        while ((tCurrent.tidID != tidCOMMA_TOKEN) && (tCurrent.tidID != tidCLOSE_TOKEN)) {
            bTake = bTRUE;
            sprintf(sUpper[iShapeCount], "%s%s", sUpper[iShapeCount], sGetTokenText(&tCurrent, sBuffer));
            GetToken(&tCurrent);
            } 
        if (tCurrent.tidID == tidCOMMA_TOKEN)
            GetToken(&tCurrent);    
        iShapeCount++;    
        } /* while (tCurrent.tidID != tidCLOSE_TOKEN) */
    GetToken(&tCurrent);
       
    if (bTake) { 
        sprintf(sLine, "%s(<", sLine);
        bFirst = bTRUE;
        for (iShapeIndex=0; iShapeIndex < iShapeCount; iShapeIndex++) {          
            if(bFirst) {
                bFirst = bFALSE;
                sprintf(sLine, "%s(", sLine);    
                }
            else
                sprintf(sLine, "%s (", sLine);    
            if (strlen(sUpper[iShapeIndex]) == 0)
                sprintf(sLine, "%s0", sLine);
            else    
                sprintf(sLine, "%s%s", sLine, sUpper[iShapeIndex]);
            if (strlen(sLower[iShapeIndex]) != 0) 
                if ((strlen(sLower[iShapeIndex]) == 1) && isdigit(sLower[iShapeIndex][0])) {
                    if ((iAdjust = atoi(sLower[iShapeIndex]) - 1) != 0)
                        sprintf(sLine, "%s-%i", sLine, iAdjust);
                    }
                else     
                    sprintf(sLine, "%s-%s+1", sLine, sLower[iShapeIndex]);
            sprintf(sLine, "%s)", sLine);    
            } /* for (iShapeIndex=0; iShapeIndex < iShapeCount; iShapeIndex++) */
        sprintf(sLine, "%s> take ", sLine);
        } /* if (bTake) */

    if (bDrop) { 
        sprintf(sLine, "%s(<", sLine);
        bFirst = bTRUE;
        for (iShapeIndex=0; iShapeIndex < iShapeCount; iShapeIndex++) {          
            if(bFirst) {
                bFirst = bFALSE;
                sprintf(sLine, "%s", sLine);    
                }
            else
                sprintf(sLine, "%s ", sLine);    
            if (strlen(sLower[iShapeIndex]) == 0)
                sprintf(sLine, "%s0", sLine);
            else if (strlen(sLower[iShapeIndex]) != 0) 
                if ((strlen(sLower[iShapeIndex]) == 1) && isdigit(sLower[iShapeIndex][0]))
                    sprintf(sLine, "%s%i", sLine, atoi(sLower[iShapeIndex]) - 1);
                else     
                    sprintf(sLine, "%s(%s-1)", sLine, sLower[iShapeIndex]);
            } /* for (iShapeIndex=0; iShpaeIndex < iShapeCount; iShapeIndex++) */
        sprintf(sLine, "%s> drop ", sLine);
        } /* if (bDrop) */
        
    sprintf (sLine,"%s%s)", sLine, sVar);
    
    if (bTake && bDrop) 
        sprintf (sLine,"%s)", sLine);
    
} /* VarAccess */

/**********************************************************
 * Procedure     Number
 *
 **********************************************************/
void Number(char *sLine) {
    char sBuffer[iMAX_LINE];
    
    if (bArrayAssignment)
        sprintf(sLine, "%s<", sLine);        
    if (tCurrent.tidID == tidMINUS_TOKEN) {
        sprintf(sLine, "%s-", sLine);      
        GetToken(&tCurrent);
        }  
    while (isdigit(sGetTokenText(&tCurrent, sBuffer)[0])) {
        sprintf(sLine, "%s%s", sLine, sBuffer);
        Match(tidIDENTIFIER_TOKEN);        
        }
    if (sGetTokenText(&tCurrent, sBuffer)[0] == '.') {
        sprintf(sLine, "%s.", sLine);
        Match(tidIDENTIFIER_TOKEN);        
        while (isdigit(sGetTokenText(&tCurrent, sBuffer)[0])) {
            sprintf(sLine, "%s%s", sLine, sBuffer);
            Match(tidIDENTIFIER_TOKEN);        
            }
        }    
    if (bArrayAssignment)
        sprintf(sLine, "%s>", sLine);        
                
} /* Number */            
                 
/**********************************************************
 * Procedure     Factor
 *
 * Description   
 *
 **********************************************************/
char *sFactor(char *sLine) {
    char sBuffer[iMAX_LINE];                  
    
    if (strlen(sLine) > NEW_LINE) {
        sprintf (sLine,"%s\n", sLine);
        sLine = asStatement[++iLineCount];
        sprintf(sLine, "%*c", iMargin + 2*MARGIN_SIZE, ' ');
        }        
    if (tCurrent.tidID == tidOPEN_TOKEN) {
        GetToken(&tCurrent);
        sprintf (sLine,"%s(", sLine);
        sLine = sExpression(sLine);
        sprintf (sLine,"%s)", sLine);
        Match(tidCLOSE_TOKEN);
        }
    else
        if (isdigit(sGetTokenText(&tCurrent, sBuffer)[0]) || tCurrent.tidID == tidMINUS_TOKEN) 
            Number(sLine);
        else                        
            VarAccess(sLine);    
                 
    return(sLine);                 
} /* Factor */            
                 
/**********************************************************
 * Procedure     TermPrime
 *
 * Description   
 *
 **********************************************************/
char *sTermPrime(char *sLine) {                  
    if (strlen(sLine) > NEW_LINE) {
        sprintf (sLine,"%s\n", sLine);
        sLine = asStatement[++iLineCount];
        sprintf(sLine, "%*c", iMargin + 2*MARGIN_SIZE, ' ');
        }        
    
    if (tCurrent.tidID == tidTIMES_TOKEN) {
        GetToken(&tCurrent);
        sprintf (sLine,"%s*", sLine);
        sLine = sFactor(sLine);
        sLine = sTermPrime(sLine);
        }
    return(sLine);    
} /* TermPrime */            
                 
/**********************************************************
 * Procedure     Term
 *
 * Description   
 *
 **********************************************************/
char *sTerm(char *sLine) {                  
    if (strlen(sLine) > NEW_LINE) {
        sprintf (sLine,"%s\n", sLine);
        sLine = asStatement[++iLineCount];
        sprintf(sLine, "%*c", iMargin + 2*MARGIN_SIZE, ' ');
        }        
    sprintf (sLine,"%s(", sLine);
    sLine = sFactor(sLine);
    sLine = sTermPrime(sLine);                              
    sprintf (sLine,"%s)", sLine);
    
    return(sLine);
} /* Term */            
                 
/**********************************************************
 * Procedure     ExpressionPrime
 *
 * Description   
 *
 **********************************************************/
char *sExpressionPrime(char *sLine) {                  
    if (strlen(sLine) > NEW_LINE) {
        sprintf (sLine,"%s\n", sLine);
        sLine = asStatement[++iLineCount];
        sprintf(sLine, "%*c", iMargin + 2*MARGIN_SIZE, ' ');
        }        
    
    if (tCurrent.tidID == tidPLUS_TOKEN) {
        GetToken(&tCurrent);
        sprintf (sLine,"%s+", sLine);
        sLine = sTerm(sLine);
        sLine = sExpressionPrime(sLine);
        }
    else if (tCurrent.tidID == tidMINUS_TOKEN) {
        GetToken(&tCurrent);
        sprintf (sLine,"%s-", sLine);
        sLine = sTerm(sLine);
        sLine = sExpressionPrime(sLine);
        }
    return(sLine);    
} /* ExpressionPrime */            
                 

/**********************************************************
 * Procedure     Expression
 *
 * Description   
 *
 **********************************************************/
char *sExpression(char *sLine) {                  
    if (strlen(sLine) > NEW_LINE) {
        sprintf (sLine,"%s\n", sLine);
        sLine = asStatement[++iLineCount];
        sprintf(sLine, "%*c", iMargin + 2*MARGIN_SIZE, ' ');
        }        
    sprintf (sLine,"%s(", sLine);
    sLine = sTerm(sLine);
    sLine = sExpressionPrime(sLine);                              
    sprintf (sLine,"%s)", sLine);
    return(sLine);
} /* Expression */            
                 
/**********************************************************
 * Procedure     AssignmentStatement
 *
 * Description   
 *
 **********************************************************/
char *sAssignmentStatement(char *sLine) {
    bArrayAssignment = bFALSE;
    sprintf(sLine, "%*c", iMargin, ' ');
    VarAccess(sLine);
    sprintf (sLine,"%s = ", sLine);
    Match(tidEQUAL_TOKEN);
    sLine = sExpression(sLine);
    sprintf (sLine,"%s;\n", sLine);
    Match(tidEOL_TOKEN);
    return(sLine);
} /* AssignmentStatement */

/**********************************************************
 * Procedure     Statement
 *
 * Description   Builds a list of MOA instructions
 *
 **********************************************************/

void Statement(void) {

    switch (tCurrent.tidID) {          
        case tidDO_TOKEN:
            DoStatement(asStatement[++iLineCount]);
            iMargin += MARGIN_SIZE;     
            while (tCurrent.tidID != tidENDDO_TOKEN)
                Statement();
            GetToken(&tCurrent); /* tidENDDO_TOKEN */
            sprintf(asStatement[++iLineCount], "%*c} # forall\n", iMargin, ' ');
            iMargin -= MARGIN_SIZE;     
            Match(tidEOL_TOKEN);
            break;
        case tidALLOCATE_TOKEN:
            AllocateStatement(asStatement[++iLineCount]);
            break;
        case tidIDENTIFIER_TOKEN:
            sAssignmentStatement(asStatement[++iLineCount]);
            break;
        default:
            perror("FATAL ERROR: An unexpected token encountered in statement");
            exit(1);
        } /* switch (tCurrent.tidID) */
} /* ExecutionPart */    
        
#pragma page ()
/**********************************************************
 * Procedure     PrintSpecifications
 *
 * Description  
 *
 **********************************************************/
void PrintSpecifications(SymbolTableRecord_t *p_strSubroutine) {
    int                 iShapeCount;                           
    int                 iArgumentCount;
    Boolean_t           bArgument;
    SymbolTableRecord_t *p_strVariable;
    SymbolTableRecord_t *p_strArgument;                              
    

    while ((p_strVariable = pstrSymbolTableRemoveAny()) != NULL) {
        if (p_strVariable !=  p_strSubroutine) {
            bArgument = bFALSE;            
            iArgumentCount = 0;
            while ((p_strArgument = p_strSubroutine->uValue.apstrArguments[iArgumentCount++]) != NULL) {
                if (p_strArgument == p_strVariable) 
                    bArgument = bTRUE;
                } /* while ((p_strArgument =... */
            if (!bArgument) {          
                if (p_strVariable->iType == STT_INTEGER) 
                    printf("    integer %s;\n", p_strVariable->sIdentifier);
                else { /* STT_ARRAY */                 
                    for (iShapeCount = 0; p_strVariable->uValue.asShape[iShapeCount] != NULL; iShapeCount++);
                    printf("    array %s^%i ", p_strVariable->sIdentifier, iShapeCount);
                    if (p_strVariable->uValue.asShape[0][0] != ':') {
                        printf("<");
                        for (iShapeCount = 0; p_strVariable->uValue.asShape[iShapeCount] != NULL; iShapeCount++) {
                            if (iShapeCount)
                                printf(" %s", p_strVariable->uValue.asShape[iShapeCount]);
                            else    
                                printf("%s", p_strVariable->uValue.asShape[iShapeCount]);
                            } /* for (;p_strVariable->... */       
                        printf(">");
                        } /* if (p_strVariable->uValue.asShape[0][0] == ':') */    
                    printf(";\n");    
                    } /* STT_ARRAY */
                } /* if (!bArgument) */
            SymbolTableRecordFree (p_strVariable);                    
            } /* if (p_strVariable !=  p_strSubroutine) */
        } /* while ((p_strVariable = pstrSymbolTableRemoveAny()) != NULL) */ 
    SymbolTableRecordFree (p_strSubroutine);                    
    
} /* PrintSpecifications */
/**********************************************************
 * Procedure     ParseF90ToMOA
 *
 * Description  
 *
 **********************************************************/

void ParseF90ToMOA (void) {            
    int  iLineIndex;
    char sSubroutineName[iMAX_LINE];            
    SymbolTableRecord_t *p_strSubroutine;
        
    printf("#***********************************************************\n");
    printf("#  This is code produced from a FORTRAN 90 source to MOA\n");
    printf("#***********************************************************\n");
    GetToken(&tCurrent);
    
    while (tCurrent.tidID != tidEOF) {
        iMargin = MARGIN_SIZE;
        while (tCurrent.tidID == tidEOL_TOKEN)
            GetToken(&tCurrent);                
        Match(tidSUBROUTINE_TOKEN);  
        strcpy (sSubroutineName, tCurrent.uAttribute.sLexeme);
        Match(tidIDENTIFIER_TOKEN);
        printf ("\n%s (", sSubroutineName);      
        p_strSubroutine = pstrSymbolTablePut (sSubroutineName);
        p_strSubroutine->iType = STT_SUBROUTINE;

        ArgumentList(p_strSubroutine);
        printf (") {\n");      
        SpecificationPart();
        iLineCount=-1;
        while (tCurrent.tidID != tidEND_TOKEN)
            Statement();

        Match(tidEND_TOKEN);
        if (tCurrent.tidID == tidSUBROUTINE_TOKEN)
            GetToken(&tCurrent);                
        if (tCurrent.tidID == tidIDENTIFIER_TOKEN)
            GetToken(&tCurrent);            
            
        PrintSpecifications(p_strSubroutine);  
        
        for (iLineIndex = 0; iLineIndex <= iLineCount; iLineIndex++)
            printf ("%s", asStatement[iLineIndex]);
        
        printf ("} # %s\n", sSubroutineName);      
            
        while (tCurrent.tidID == tidEOL_TOKEN)
            GetToken(&tCurrent);                
        } /* while (tCurrent.tidID != tidEOF) */    

}  /* ParseF90ToMOA */
