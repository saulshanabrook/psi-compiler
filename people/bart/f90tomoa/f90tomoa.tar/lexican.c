#pragma message ("Copyright (c) 1993 Bart Fitzgerald -  All rights reserved")

/********************************************************************
 * THIS SOFTWARE IS PROVIDED BY THE DEVELOPER ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE DEVELOPER BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 ********************************************************************/
#pragma subtitle ("Lexican.c v 0.404")

/********************************************************************
 * Filename Lexya2c2.c
 * ProGrammar   Bart Fitzgerald
 *
 * Description  This is a portion of a compiler that performs the
 *              lexical analysis.  The token selection is dependent
 *              on the .e and .h files.
 *
 *              The .e file contains information that other segments
 *              require to use Lex.c.  Language dependent #defines for
 *              token IDs and Modifiers are found here.
 *              Also usage notes for Lex.c are found here.
 *
 *              The .h file contains language dependent information
 *              that is required for Lex.c.  Comment delimiters,
 *              a predefined token table, Token ID to text table,
 *              token modifier to text table, and identifier starters
 *              and characters are all found here.
 *
 *
 * Externals    cGetValidChar   io.c
 * Used         UngetValidChar  io.c
 *              Warn            io.c
 *              Error           io.c
 *
 * Version  0.00 09/15/93 Initial code
 *          0.01 09/17/93 Token selection control from the
 *                .e and .h files.
 *          0.03.000 11/17/93 Bart
 *                  Added GetTokenToEOL
 *
 *
 ********************************************************************/

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "standard.h"

#include "lexya2c2.e"
#include "lexya2c2.h"
#include "io.h"

/**************
 * Size defines for this segment
 **************/

#define iMAX_IDENTIFIER     50  /* the maximum size of identifiers */
#define iMAX_DIGITS         90  /* the maximum digits for numbers  */
                                /*    including decimal point      */

/**********************
 * Identifier starters and charaters
 **********************/

char *sIdentifierStarters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
char *sIdentifierCharacters =
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz";

/**************
 * Segment Variables
 **************/

char *pcCurrent;

/**************
 * Forward Declarations
 **************/

void      AssignCharToken (Token_t *ptToken);
void      AssignNumericToken (Token_t *ptToken);
void      AssignOtherToken (Token_t *ptToken);
void      SortString (char *sSort);
void      SortTokenTable (struct stTokenTable_t *attTable, int iLow, int iHigh);
Boolean_t bMemberOf (char cSearchee, char *sMembers);

#pragma page ()
/**********************************************************
 * Procedure     bInitializeLexican
 *
 * Description   Loads *pcCurrent with the first character
 *       from the input stream.
 *
 * Precondition  The input stream must be open.
 *
 * Postcondition The *pcCurrent contains the first character from
 *       the input stream.
 *       sIdentifierStarters, sIdentifierCharacters,
 *       and astPredefinedTokens are sorted.
 *
 * Param     none
 *
 * Return    bTRUE if a character is loaded
 *       bFALSE otherwise
 *
 **********************************************************/

Boolean_t bInitializeLexican (void) {
    int iIndex;
    
    pcCurrent = sGetSourceLine();
    if (pcCurrent == NULL)
        return (bFALSE);

        /* sorting required to avoid linear searching */
    SortString(sIdentifierStarters);
    SortString(sIdentifierCharacters);
    SortTokenTable(attOtherToken, 0, iOTHER_TOKEN_COUNT-1);
        /* sort reserved word within respective strlen sizes */
    for (iIndex=0; iIndex <= iRESERVED_WORD_MAX_SIZE; iIndex++)
        SortTokenTable(attReservedWord,
               aiReservedWordIndex[iIndex],
               aiReservedWordIndex[iIndex+1]-1);

    return (bTRUE);

}  /* bInitializeLexican */

#pragma page ()
/**********************************************************
 * Procedure     InitializeToken
 *
 * Description   Prepares a token for use.
 *
 * Precondition  ptNew contains a pointer to a token.
 *
 * Postcondition ptNew has default assignments.
 *
 * Param     ptNew - a new token.
 *
 * Return    void
 *
 **********************************************************/
void InitializeToken(Token_t *ptNew) {
    ptNew->tidID = tidINVALID_TOKEN;
}  /* bInitializeToken */

#pragma page ()
/**********************************************************
 * Procedure     sGetTokenText
 *
 * Description   Returns a pointer to a text string of a
 *       token.
 *
 * Precondition  tToken contains a valid token.
 *
 * Postcondition A pointer to a string Description is returned.
 *
 * Param     tToken  - a token to be discribed
 *       sBuffer - the buffer for the Description.
 *
 * Return    A pointer to sBuffer
 *
 **********************************************************/
char *sGetTokenText(Token_t *ptToken, char *sBuffer) {
    if (ptToken->tidID == tidIDENTIFER_TOKEN)
        sprintf (sBuffer, "%s", ptToken->uAttribute.sLexeme);
    else
        sprintf (sBuffer, "%s", asTokenID[ptToken->tidID]);
    return(sBuffer);
}  /* sGetTokenText */

#pragma page ()
/**********************************************************
 * Procedure    GetTokenToEOL
 *
 * Description      Get from the current location to the
 *                  \n or end of file
 *
 * Precondition     *pcCurrent must contain a character from
 *                  the character stream.
 *
 * Postcondition    The members of tidID is set to tidINVALID_TOKEN
 *                  sLexeme points to a string containing the rest 
 *                  of the input line.
 *
 * Param     ptToken - A pointer to the token to be returned
 *
 * Return    void
 **********************************************************/
void GetTokenToEOL(Token_t *ptToken) {

        /* manage memory here */
    if ((ptToken != NULL) && (ptToken->tidID == tidIDENTIFER_TOKEN)) {
        free (ptToken->uAttribute.sLexeme);
        ptToken->tidID = tidINVALID_TOKEN;
        }  /* if (ptToken->tidID ==... */
        for (; (isspace(*pcCurrent))&&(*pcCurrent != '\n'); pcCurrent++);
    
    ptToken->tidID    = tidIDENTIFER_TOKEN;
    if ((ptToken->uAttribute.sLexeme = (char *)malloc(strlen(pcCurrent)+1)) == NULL)
        FatalError(iMEMORY_ALLOCATION_ERROR, "Lexican.c");
    strcpy (ptToken->uAttribute.sLexeme, pcCurrent);
    
    pcCurrent = sGetSourceLine();
} /* GetToken */

#pragma page ()
/**********************************************************
 * Procedure     GetToken
 *
 * Description   Finds the next token in the charater stream
 *
 * Precondition  *pcCurrent must contain a character from
 *       the character stream.
 *
 * Postcondition The members of ptToken are assigned based on
 *       charater(s) from the character stream.
 *       The *pcCurrent contains the next character from
 *       the input stream.
 *
 * Param     ptToken - A pointer to the token to be returned
 *
 * Return    void
 **********************************************************/

void GetToken(Token_t *ptToken) {
    Boolean_t bComment = bFALSE;

        /* manage memory here */
    if ((ptToken != NULL) && (ptToken->tidID == tidIDENTIFER_TOKEN)) {
        free (ptToken->uAttribute.sLexeme);
        ptToken->tidID = tidINVALID_TOKEN;
        }  /* if (ptToken->tidID ==... */

 GetToken_TailRecursion:  /* well, almost tail recursion */

    if (pcCurrent == NULL)
        ptToken->tidID = tidEOF;        
    else {
                    /* clear white space */
        for (; (isspace(*pcCurrent))&&(*pcCurrent != '\n'); pcCurrent++);
                    /* assign token */
        if (bMemberOf(*pcCurrent, sIdentifierStarters))
            AssignCharToken(ptToken);
        else if ((*pcCurrent == '\0') || (*pcCurrent == '\n')) {
            pcCurrent = sGetSourceLine();
            goto GetToken_TailRecursion;
            }
        else
            AssignOtherToken(ptToken);
        }    

                /* comment to end of line */
    if (ptToken->tidID == tidCOMMENT_EOL_TOKEN) {
        while (((*(++pcCurrent)) != '\n') && (*pcCurrent != '\0'));
            goto GetToken_TailRecursion;
        }  /* if (ptToken->tidID == tidCOMMENT_EOL_TOKEN) */
    else if (ptToken->tidID == tidINVALID_TOKEN) {
        Error(iINVALID_TOKEN_ERROR, ptToken->uAttribute.sLexeme);
        goto GetToken_TailRecursion;
        }  /* if (ptToken->tidID == tidINVALID_TOKEN) */

    #if defined (DEBUGLEX) 
        {
        char sBuffer[80];
        if (ptToken->tidID = tidEOF)
            printf("Source EOF");
        else    
            printf ("%s ", sGetTokenText(ptToken, sBuffer));
        }
    #endif
}  /* GetToken */

#pragma page ()
/**********************************************************
 * Procedure     AssignCharToken
 *
 * Description   Builds a string and checks it against the
 *       reserved words for a token assignment. If
 *       it is not a reverved word then it is a token.
 *
 * Precondition  cCurrent is an alpha character.
 *
 * Postcondition The members of ptToken are assigned based on
 *       charater(s) from the character stream.
 *       The cCurrent contains the next character from
 *       the input stream.
 *
 * Param     ptToken - A pointer to the token to be returned
 *
 * Return    void
 **********************************************************/

void AssignCharToken(Token_t *ptToken) {
    char      sLexeme[iMAX_IDENTIFIER+1];   /* place to build the string     */
    int       iPosition = 1;                /* position in the string        */
    Boolean_t bIdentifier = bTRUE;          /* False if string is reserved word  */

                    /* build the string */
    for (sLexeme[0] = *pcCurrent;
            (bMemberOf(*(++pcCurrent), sIdentifierCharacters)) &&
            (iPosition < iMAX_IDENTIFIER);
        sLexeme[iPosition++] = *pcCurrent);
    sLexeme[iPosition] = '\0';

                    /* eject excess characters */
    if ((iPosition >= iMAX_IDENTIFIER) && (bMemberOf(*pcCurrent, sIdentifierCharacters))) {
        while (bMemberOf(*(++pcCurrent), sIdentifierCharacters));
            Warn (iIDENTIFIER_TRUNCATION, "");
        }  /* if ((iPosition... */

                    /* bsearch reserved words */
    if (iPosition <= iRESERVED_WORD_MAX_SIZE) {
        int iMin = aiReservedWordIndex[iPosition];
        int iMax = aiReservedWordIndex[iPosition+1]-1;
        int iMid;
        int iResult;

        if (iMin <= iMax)
            while (bIdentifier && (iMin <= iMax))
                if ((iResult = strcmp(sLexeme, attReservedWord[iMid = (iMin+iMax)/2].sLexeme)) < 0)
                    iMax = iMid-1;
                else if (iResult > 0)
                    iMin = iMid+1;
                else {  /* got it */
                    bIdentifier    = bFALSE;
                    ptToken->tidID = attReservedWord[iMid].tidID;
                    }  /* got it */
        }  /* if (iPosition <= iRESERVED_WORD_MAX_SIZE) */

                    /* assign identifier */
    if (bIdentifier) {
        ptToken->tidID    = tidIDENTIFER_TOKEN;
        if ((ptToken->uAttribute.sLexeme = (char *)malloc(strlen(sLexeme)+(size_t)1)) == NULL)
            FatalError(iMEMORY_ALLOCATION_ERROR, "Proceedure - AssignCharToken in Lexican.c");
        strcpy (ptToken->uAttribute.sLexeme, sLexeme);
    }  /* if (bIdentifier) */


}  /* AssignCharToken */



#pragma page ()
/**********************************************************
 * Procedure     AssignOtherToken
 *
 * Description   Finds and assigns predefined tokens.
 *
 * Precondition  astPredefinedToken contain the predefined token table.
 *       cCurrent contains a character from the source stream.
 *
 * Postcondition The members of ptToken are assigned based on
 *       charater(s) from the character stream.
 *       The cCurrent contains the next character from
 *       the input stream.
 *
 * Param     ptToken - A pointer to the token to be returned
 *
 * Return    bTRUE if this is a predefined token, otherwise bFALSE.
 **********************************************************/

void AssignOtherToken (Token_t *ptToken) {
    int       iMax   = iOTHER_TOKEN_COUNT;
    int       iMin   =  0;
    int       iMid;
    int       iMatch     = -1;  /* the largest matched lexeme thus far */
    int       iMatchSize =  0;  /* the size of the iMatch lexeme       */
    int       iChar      =  0;
    char      *pcStart;
    char      *pcNextCurrent;
    char      cChar;
                     
    pcStart = pcCurrent;
    pcNextCurrent = pcCurrent+1;
                         
            /* bsearch the 'other' token table one character at a time */
    while (iMin <= iMax) {
        if (*pcCurrent < (cChar = attOtherToken[iMid = (iMin+iMax)/2].sLexeme[iChar]))
            iMax = iMid-1;
        else if (*pcCurrent > cChar)
            iMin = iMid+1;
        else  { /* character match */
            for (iMin=iMid-1; (iMin >= 0) && 
                    (*pcCurrent == (cChar = attOtherToken[iMin].sLexeme[iChar])); iMin--);
            if ((iMin < 0) || (*pcCurrent != cChar))
                iMin++;
            for (iMax=iMid+1; (iMax < iOTHER_TOKEN_COUNT) && 
                    (*pcCurrent == (cChar = attOtherToken[iMax].sLexeme[iChar])); iMax++);
            if ((iMax >= iOTHER_TOKEN_COUNT) || (*pcCurrent != cChar))
                iMax--;
            if (attOtherToken[iMin].sLexeme[++iChar] == '\0') {
                iMatch     = iMin;
                iMatchSize = iChar;
                pcNextCurrent = pcCurrent+1;
                }  /* if (attOtherToken[iMin].sLexeme[iChar] == '\0') */
            ++pcCurrent;
            }  /* character match */
        }  /* while (iMin <= iMax) */

    /* assign token and return excess or retrive needed characters */
    if (iMatch >= 0)
        ptToken->tidID  = attOtherToken[iMatch].tidID;
    else {  /* iMatch < 0 */
        ptToken->tidID = tidIDENTIFER_TOKEN;
        if (bCALLOC(ptToken->uAttribute.sLexeme, 2, char))
            FatalError(iMEMORY_ALLOCATION_ERROR, "Lex TXL");
        ptToken->uAttribute.sLexeme[0] = *pcStart;
        ptToken->uAttribute.sLexeme[1] = '\0';
        }  /* iMatch < 0 */
        
    pcCurrent = pcNextCurrent;

}  /* AssignOtherToken */

#pragma page ()
/**********************************************************
 * Procedure     SortString
 *
 * Description   Sorts the characters in a string.
 *
 * Precondition  sSort is a '\0' terminated string.
 *
 * Postcondition The members of sSort are in acending order.
 *
 * Param     sSort - A pointer to the string to be sorted.
 *
 * Return    void
 **********************************************************/
void SortString(char *sSort) {

    int  iSize = strlen(sSort);
    int  iInner;
    int  iOuter;
    char cTemp;
    Boolean_t bSwap = bTRUE;

    for (iOuter=0; (iOuter < iSize-1) && bSwap; iOuter++) {
    bSwap = bFALSE;
    for (iInner=iSize-1; iInner > iOuter; iInner--)
        if (sSort[iInner] < sSort[iInner-1]) {
        bSwap = bTRUE;
        cTemp       = sSort[iInner];
        sSort[iInner]   = sSort[iInner-1];
        sSort[iInner-1] = cTemp;
        }  /* if (sSort[iInner] <... */
    }  /* for (iOuter=0... */



}  /* SortString */


#pragma page ()
/**********************************************************
 * Procedure     TokenTableCopy
 *
 * Description   Copies a member of a token table to another.
 *
 * Precondition  none
 *
 * Postcondition pttDestination has the same information as pttSource.
 *
 * Param     pttDestination - the destination for the information.
 *       pttSource  - the source of the information.
 *
 * Return    void
 **********************************************************/
void TokenTableCopy(struct stTokenTable_t *pttDestination,
            struct stTokenTable_t *pttSource) {

    strcpy(pttDestination->sLexeme, pttSource->sLexeme);
    pttDestination->tidID     = pttSource->tidID;

}  /* TokenTableCopy */

#pragma page ()
/**********************************************************
 * Procedure     SortPredefinedTokens
 *
 * Description   Quick sorts the predefined token table.
 *
 * Precondition  astPredefinedToken contains the predefined tokens.
 *
 * Postcondition The members of astPredefinedToken are arranged in
 *       acending order.
 *
 * Param     void
 *
 * Return    void
 **********************************************************/
void SortTokenTable(struct stTokenTable_t *attTable, int iLow, int iHigh) {
    int  iInner;
    int  iOuter;
    struct stTokenTable_t ttTemp;
    Boolean_t bSwap = bTRUE;

    for (iOuter=iLow; (iOuter < iHigh) && bSwap; iOuter++) {
    bSwap = bFALSE;
    for (iInner=iHigh; iInner > iOuter; iInner--)
        if (strcmp(attTable[iInner].sLexeme, attTable[iInner-1].sLexeme) < 0) {
        bSwap = bTRUE;
        TokenTableCopy (&ttTemp,         &attTable[iInner]);
        TokenTableCopy (&attTable[iInner],   &attTable[iInner-1]);
        TokenTableCopy (&attTable[iInner-1], &ttTemp);
        }  /* if (strcmp(attTable... */
    }  /* for (iOuter=iLow... */

}  /* SortTokenTable */

#pragma page ()
/**********************************************************
 * Procedure     bMemberOf
 *
 * Description   Bsearchs sMembers for cSearchee
 *
 * Precondition  sMembers is a sorted null terminated string
 *
 * Postcondition A boolean that indicated cSearchee's presence
 *       in sMembers
 *
 * Param     cSearchee - the caracter to be searched for
 *       sMembers  - the set of acceptable characters
 *
 * Return    void
 **********************************************************/
Boolean_t bMemberOf (char cSearchee, char *sMembers) {
    int iMin = 0;
    int iMax = strlen(sMembers)-1;
    int iMid;

    while (iMin <= iMax)
    if (cSearchee < sMembers[iMid = (iMin+iMax)/2])
        iMax = iMid-1;
    else if (cSearchee > sMembers[iMid])
        iMin = iMid+1;
    else
        return (bTRUE);

    return (bFALSE);

}  /* SortTokenTable */
